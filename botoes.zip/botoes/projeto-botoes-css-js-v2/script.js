/* =========================================================
   01. SELEÇÃO DOS ELEMENTOS PRINCIPAIS
   ========================================================= */

/* Seleciona a área de mensagens. */
const status = document.getElementById("status");

/* Seleciona o campo de pesquisa. */
const search = document.getElementById("search");

/* Seleciona o campo do tema. */
const theme = document.getElementById("theme");

/* Seleciona todos os cartões da página e transforma em array. */
const cards = [...document.querySelectorAll(".card")];

/* =========================================================
   02. FUNÇÃO DE MENSAGEM
   ========================================================= */

/* Função pequena para mudar o texto do status. */
function notify(message) {
  status.textContent = message;
}

/* =========================================================
   03. CLIQUE GLOBAL
   ========================================================= */

/*
  O document recebe um listener geral.
  Isso permite detectar cliques em vários botões sem
  precisar escrever o mesmo código repetidamente.
*/
document.addEventListener("click", (event) => {

  /* Procura o botão ou link mais próximo do elemento clicado. */
  const button = event.target.closest("button, a");

  /* Se o clique não foi em botão/link, não fazemos nada. */
  if (!button) {
    return;
  }

  /* Links internos possuem comportamento próprio. */
  if (button.classList.contains("btn-link")) {
    return;
  }

  /* Pega o texto visível do botão. */
  const text =
    button.innerText
      ?.trim()
      .replace(/\s+/g, " ")
    || "Botão";

  /* Mostra no status. */
  notify(`Você clicou em: ${text}`);
});

/* =========================================================
   04. PESQUISA
   ========================================================= */

/*
  A cada alteração do campo de pesquisa,
  percorremos todos os cartões e verificamos
  se data-name contém a palavra procurada.
*/
search.addEventListener("input", () => {

  /* Converte a pesquisa para minúsculas e remove espaços extras. */
  const query =
    search.value
      .toLowerCase()
      .trim();

  /* Passa por cada cartão. */
  cards.forEach((card) => {

    /* Verifica se o nome do cartão contém a pesquisa. */
    const match =
      card.dataset.name.includes(query);

    /* Esconde o cartão quando não existe correspondência. */
    card.classList.toggle(
      "hidden",
      !match
    );
  });

  /* Mostra no status a quantidade encontrada. */
  const visibleCards =
    cards.filter(
      (card) =>
        !card.classList.contains("hidden")
    ).length;

  notify(
    query
      ? `${visibleCards} botão(ões) encontrado(s).`
      : "Todos os botões estão visíveis."
  );
});

/* =========================================================
   05. TROCA DE TEMA
   ========================================================= */

/* Quando o usuário troca o select... */
theme.addEventListener("change", () => {

  /* Adicionamos ou removemos a classe "light" do body. */
  document.body.classList.toggle(
    "light",
    theme.value === "light"
  );

  /* Feedback visual. */
  notify(
    theme.value === "light"
      ? "☀️ Tema claro ativado."
      : "🌙 Tema escuro ativado."
  );
});

/* =========================================================
   06. BOTÃO ALEATÓRIO
   ========================================================= */

/* Seleciona o botão de escolha aleatória. */
document
  .getElementById("randomDemo")
  .addEventListener("click", () => {

    /* Considera apenas cartões que estão visíveis. */
    const visible =
      cards.filter(
        (card) =>
          !card.classList.contains("hidden")
      );

    /* Caso nenhum cartão esteja disponível. */
    if (!visible.length) {
      notify("Nenhum botão corresponde à pesquisa.");
      return;
    }

    /* Escolhe um índice aleatório. */
    const randomIndex =
      Math.floor(
        Math.random() * visible.length
      );

    /* Pega o cartão sorteado. */
    const chosen = visible[randomIndex];

    /* Rola a tela até ele. */
    chosen.scrollIntoView({
      behavior: "smooth",
      block: "center"
    });

    /* Cria uma pequena animação de destaque. */
    chosen.animate(
      [
        { transform: "scale(1)" },
        { transform: "scale(1.03)" },
        { transform: "scale(1)" }
      ],
      {
        duration: 500,
        easing: "ease-out"
      }
    );

    /* Mostra qual botão foi sorteado. */
    notify(
      `🎲 Sorteado: ${
        chosen.querySelector("h2").textContent
      }`
    );
  });

/* =========================================================
   07. BOTÃO DE LOADING
   ========================================================= */

/*
  Seleciona todos os exemplos que possuem
  a classe js-loading.
*/
document
  .querySelectorAll(".js-loading")
  .forEach((button) => {

    /* Listener executado ao clicar. */
    button.addEventListener("click", () => {

      /* Evita iniciar outro processo enquanto já está carregando. */
      if (button.classList.contains("loading")) {
        return;
      }

      /* Guardamos o conteúdo original. */
      const original = button.innerHTML;

      /* Adicionamos o estado de carregamento. */
      button.classList.add("loading");

      /* Troca o texto. */
      button.textContent = "Processando...";

      /* Simulamos uma operação de 1,8 segundos. */
      setTimeout(() => {

        /* Removemos o estado de loading. */
        button.classList.remove("loading");

        /* Voltamos ao conteúdo original. */
        button.innerHTML = original;

        /* Feedback. */
        notify("✅ Processamento concluído.");
      }, 1800);
    });
  });

/* =========================================================
   08. TOGGLE
   ========================================================= */

document
  .querySelectorAll(".toggle")
  .forEach((toggle) => {

    toggle.addEventListener("click", () => {

      /* Lemos o estado atual do atributo aria-pressed. */
      const active =
        toggle.getAttribute("aria-pressed") === "true";

      /* Invertendo o valor, transformamos ON em OFF ou vice-versa. */
      toggle.setAttribute(
        "aria-pressed",
        String(!active)
      );

      /* Muda o texto mostrado. */
      toggle.querySelector("strong").textContent =
        active
          ? "OFF"
          : "ON";
    });
  });

/* =========================================================
   09. RIPPLE EFFECT
   ========================================================= */

/*
  O efeito ripple precisa saber onde aconteceu o clique.
  Para isso usamos a posição do mouse dentro do botão.
*/
document
  .querySelectorAll(".btn-ripple")
  .forEach((button) => {

    button.addEventListener("click", (event) => {

      /* Descobrimos posição e tamanho do botão. */
      const rect =
        button.getBoundingClientRect();

      /* Calculamos a posição do clique dentro dele. */
      const x =
        event.clientX - rect.left;

      const y =
        event.clientY - rect.top;

      /* Guardamos as posições em variáveis CSS. */
      button.style.setProperty(
        "--x",
        `${x}px`
      );

      button.style.setProperty(
        "--y",
        `${y}px`
      );

      /* Reiniciamos a animação para permitir vários cliques. */
      button.classList.remove("ripple");

      /* Forçamos o navegador a recalcular o layout. */
      void button.offsetWidth;

      /* Ativamos a classe que inicia o efeito. */
      button.classList.add("ripple");

      /* Removemos depois da duração da animação. */
      setTimeout(() => {
        button.classList.remove("ripple");
      }, 700);
    });
  });

/* =========================================================
   10. BOTÃO MAGNÉTICO
   ========================================================= */

/*
  O botão acompanha de forma suave a posição do mouse.
  A conta multiplica o deslocamento por 0.18 para
  não deixar o movimento exagerado.
*/
document
  .querySelectorAll(".btn-magnetic")
  .forEach((button) => {

    button.addEventListener("mousemove", (event) => {

      /* Descobrimos a posição e tamanho do botão. */
      const rect =
        button.getBoundingClientRect();

      /* Centro horizontal do botão. */
      const centerX =
        rect.left + rect.width / 2;

      /* Centro vertical do botão. */
      const centerY =
        rect.top + rect.height / 2;

      /* Quanto o mouse está distante do centro. */
      const distanceX =
        event.clientX - centerX;

      const distanceY =
        event.clientY - centerY;

      /* Aplicamos uma fração desse deslocamento. */
      const x = distanceX * 0.18;
      const y = distanceY * 0.18;

      /* Movemos o botão. */
      button.style.transform =
        `translate(${x}px, ${y}px)`;
    });

    /* Ao sair do botão, ele volta ao lugar. */
    button.addEventListener("mouseleave", () => {
      button.style.transform = "";
    });
  });

/* =========================================================
   11. HAMBURGER
   ========================================================= */

document
  .querySelectorAll(".hamburger")
  .forEach((button) => {

    button.addEventListener("click", () => {

      /* Alterna a classe visual "open". */
      button.classList.toggle("open");

      /* Descobre se está aberto. */
      const isOpen =
        button.classList.contains("open");

      /* Atualiza o atributo de acessibilidade. */
      button.setAttribute(
        "aria-expanded",
        String(isOpen)
      );

      /* Atualiza também a descrição para leitores de tela. */
      button.setAttribute(
        "aria-label",
        isOpen
          ? "Fechar menu"
          : "Abrir menu"
      );
    });
  });

/* =========================================================
   12. SQUISHY
   ========================================================= */

document
  .querySelectorAll(".btn-squishy")
  .forEach((button) => {

    button.addEventListener("click", () => {

      /* Remove para reiniciar a animação. */
      button.classList.remove("squish");

      /* Força recálculo do layout. */
      void button.offsetWidth;

      /* Ativa a animação. */
      button.classList.add("squish");
    });
  });

/* =========================================================
   13. COPY / CLIPBOARD
   ========================================================= */

document
  .querySelectorAll(".btn-copy")
  .forEach((button) => {

    button.addEventListener("click", async () => {

      /* Pegamos o valor do atributo data-copy. */
      const value =
        button.dataset.copy;

      try {
        /* A API Clipboard escreve o conteúdo no sistema. */
        await navigator.clipboard.writeText(value);

        /* Guardamos o texto original. */
        const original =
          button.innerHTML;

        /* Informamos visualmente que copiou. */
        button.innerHTML =
          "✅ Copiado!";

        /* Depois de 1,2 segundos, voltamos ao normal. */
        setTimeout(() => {
          button.innerHTML =
            original;
        }, 1200);

        notify(
          `"${value}" foi copiado para a área de transferência.`
        );
      } catch (error) {
        /* Caso o navegador bloqueie a ação. */
        notify(
          "❌ O navegador bloqueou a cópia automática."
        );
      }
    });
  });

/* =========================================================
   14. DOWNLOAD COM PROGRESSO
   ========================================================= */

document
  .querySelectorAll(".btn-download")
  .forEach((button) => {

    button.addEventListener("click", () => {

      /* Evita iniciar duas simulações. */
      if (button.classList.contains("downloaded")) {
        return;
      }

      /* Desabilita durante o processo. */
      button.disabled = true;

      /* Guarda o nome original. */
      const original =
        button.textContent;

      /* Começa em zero. */
      let progress = 0;

      /* Atualiza o progresso a cada 220 ms. */
      const timer =
        setInterval(() => {

          progress += 20;

          button.textContent =
            `Baixando ${progress}%`;

          /* Quando chegar a 100, encerra. */
          if (progress >= 100) {

            clearInterval(timer);

            button.disabled = false;

            button.classList.add("downloaded");

            button.textContent =
              "✓ Download concluído";

            notify(
              "✅ Download simulado concluído."
            );

            /* Depois volta ao estado original. */
            setTimeout(() => {
              button.classList.remove("downloaded");
              button.textContent = original;
            }, 1800);
          }
        }, 220);
    });
  });

/* =========================================================
   15. DOUBLE CLICK
   ========================================================= */

/*
  O dblclick é um evento nativo do navegador.
  Ele acontece quando o usuário executa dois cliques rapidamente.
*/
document
  .querySelectorAll(".btn-double")
  .forEach((button) => {

    button.addEventListener("dblclick", () => {

      button.classList.remove("liked");

      /* Reinicia a animação. */
      void button.offsetWidth;

      button.classList.add("liked");

      button.textContent =
        "💖 Curtido!";

      notify(
        "💖 O evento de duplo clique foi acionado."
      );

      setTimeout(() => {
        button.textContent =
          "❤️ Clique 2x";
      }, 1200);
    });
  });

/* =========================================================
   16. LONG PRESS
   ========================================================= */

/*
  Para detectar uma pressão longa,
  começamos um timer quando o mouse entra em estado de pressionado.
*/
document
  .querySelectorAll(".btn-long")
  .forEach((button) => {

    let holdTimer = null;
    let progressTimer = null;

    /* Inicia a contagem. */
    function startHold() {

      /* Evita duplicar timers. */
      clearTimeout(holdTimer);
      clearInterval(progressTimer);

      let progress = 0;

      button.classList.add("charging");
      button.style.setProperty(
        "--hold-progress",
        "0%"
      );

      /* Atualiza o progresso visual. */
      progressTimer =
        setInterval(() => {
          progress += 10;

          button.style.setProperty(
            "--hold-progress",
            `${progress}%`
          );
        }, 100);

      /* Depois de 1 segundo, confirma a ação. */
      holdTimer =
        setTimeout(() => {

          clearInterval(progressTimer);

          button.classList.remove("charging");

          button.style.removeProperty(
            "--hold-progress"
          );

          button.textContent =
            "✓ Segurado!";

          notify(
            "✅ Pressão longa detectada."
          );

          setTimeout(() => {
            button.textContent =
              "Segure";
          }, 1200);

        }, 1000);
    }

    /* Cancela a pressão quando o usuário solta. */
    function cancelHold() {
      clearTimeout(holdTimer);
      clearInterval(progressTimer);

      button.classList.remove("charging");

      button.style.removeProperty(
        "--hold-progress"
      );
    }

    /* Eventos de mouse para desktop. */
    button.addEventListener(
      "mousedown",
      startHold
    );

    button.addEventListener(
      "mouseup",
      cancelHold
    );

    button.addEventListener(
      "mouseleave",
      cancelHold
    );

    /* Eventos touch para celular. */
    button.addEventListener(
      "touchstart",
      startHold,
      { passive: true }
    );

    button.addEventListener(
      "touchend",
      cancelHold
    );
  });

/* =========================================================
   17. CONFIRMAR EXCLUSÃO
   ========================================================= */

document
  .querySelectorAll(".btn-confirm")
  .forEach((button) => {

    button.addEventListener("click", () => {

      /* Mostramos um segundo estado no mesmo botão. */
      if (!button.classList.contains("confirmed")) {

        button.classList.add("confirmed");

        button.textContent =
          "✓ Excluído";

        notify(
          "Item confirmado como excluído."
        );

        setTimeout(() => {
          button.classList.remove("confirmed");
          button.textContent =
            "Excluir item";
        }, 1500);

      }
    });
  });

/* =========================================================
   18. SPLIT BUTTON
   ========================================================= */

document
  .querySelectorAll(".split")
  .forEach((split) => {

    const arrow =
      split.querySelector(".split-arrow");

    const main =
      split.querySelector(".split-main");

    const menuButtons =
      split.querySelectorAll(".split-menu button");

    /* Abre e fecha o menu secundário. */
    arrow.addEventListener("click", (event) => {

      /* Evita que o clique chegue ao document. */
      event.stopPropagation();

      const opened =
        split.classList.toggle("open");

      arrow.setAttribute(
        "aria-expanded",
        String(opened)
      );
    });

    /* Ação principal do botão. */
    main.addEventListener("click", () => {

      main.textContent =
        "✓ Salvo!";

      notify(
        "Ação principal do Split Button executada."
      );

      setTimeout(() => {
        main.textContent =
          "Salvar";
      }, 1200);
    });

    /* Cada item secundário mostra sua escolha. */
    menuButtons.forEach((item) => {
      item.addEventListener("click", () => {

        notify(
          `Opção escolhida: ${item.textContent}`
        );

        split.classList.remove("open");

        arrow.setAttribute(
          "aria-expanded",
          "false"
        );
      });
    });
  });

/* =========================================================
   19. PROGRESS CIRCULAR
   ========================================================= */

document
  .querySelectorAll(".progress-btn")
  .forEach((button) => {

    let running = false;

    button.addEventListener("click", () => {

      /* Evita iniciar duas vezes. */
      if (running) {
        return;
      }

      running = true;

      let progress = 0;

      /* Texto inicial. */
      button.querySelector("span").textContent =
        "0%";

      /* Timer para aumentar o progresso. */
      const timer =
        setInterval(() => {

          progress += 10;

          /* Atualiza a variável de progresso. */
          button.dataset.progress =
            String(progress);

          /* 100% de progresso equivale a 360 graus. */
          const degrees =
            progress * 3.6;

          /* O conic-gradient cria o preenchimento. */
          button.style.background =
            `conic-gradient(
              #7c3aed ${degrees}deg,
              #263044 ${degrees}deg
            )`;

          button.querySelector("span").textContent =
            `${progress}%`;

          /* Finalização. */
          if (progress >= 100) {

            clearInterval(timer);

            button.querySelector("span").textContent =
              "✓";

            notify(
              "✅ Progresso concluído."
            );

            setTimeout(() => {

              progress = 0;

              button.style.background =
                `conic-gradient(
                  #7c3aed 0deg,
                  #263044 0deg
                )`;

              button.querySelector("span").textContent =
                "Iniciar";

              running = false;

            }, 1400);
          }

        }, 120);
    });
  });

/* =========================================================
   20. HOVER TEXT
   ========================================================= */

document
  .querySelectorAll(".btn-hover-text")
  .forEach((button) => {

    /* Guardamos referências dos valores definidos no HTML. */
    const defaultText =
      button.dataset.default;

    const hoverText =
      button.dataset.hover;

    /* Durante o mouseover, mostramos outro texto. */
    button.addEventListener("mouseenter", () => {
      button.querySelector("span").textContent =
        hoverText;
    });

    /* Ao sair, voltamos ao texto original. */
    button.addEventListener("mouseleave", () => {
      button.querySelector("span").textContent =
        defaultText;
    });
  });

/* =========================================================
   21. NOTIFICAÇÃO
   ========================================================= */

document
  .querySelectorAll(".notification-btn")
  .forEach((button) => {

    button.addEventListener("click", () => {

      /* Ativa a animação do sino. */
      button.classList.remove("shake");

      void button.offsetWidth;

      button.classList.add("shake");

      /* Lemos o contador atual. */
      const badge =
        button.querySelector("span");

      let amount =
        Number(badge.textContent);

      /* Zeramos as notificações. */
      badge.textContent = "0";

      notify(
        `🔔 Você abriu suas notificações. Antes eram ${amount}.`
      );
    });
  });

/* =========================================================
   22. FAVORITO
   ========================================================= */

document
  .querySelectorAll(".favorite-btn")
  .forEach((button) => {

    button.addEventListener("click", () => {

      /* Alterna entre favorito e não favorito. */
      const active =
        button.classList.toggle("active");

      /* Troca o ícone. */
      button.querySelector("span").textContent =
        active
          ? "♥"
          : "♡";

      /* Atualiza acessibilidade. */
      button.setAttribute(
        "aria-label",
        active
          ? "Remover dos favoritos"
          : "Adicionar aos favoritos"
      );

      notify(
        active
          ? "❤️ Adicionado aos favoritos."
          : "♡ Removido dos favoritos."
      );
    });
  });

/* =========================================================
   23. SLIDE TO CONFIRM
   ========================================================= */

/*
  Este exemplo funciona com mouse e toque.
  O usuário arrasta o círculo para a direita.
*/
document
  .querySelectorAll(".slide-confirm")
  .forEach((button) => {

    const knob =
      button.querySelector(".slide-knob");

    const text =
      button.querySelector("strong");

    let dragging = false;
    let startX = 0;
    let currentX = 0;

    /* Limite máximo de movimento. */
    const maxMove = 130;

    function startDrag(clientX) {
      if (button.classList.contains("completed")) {
        return;
      }

      dragging = true;
      startX = clientX;
      currentX = 0;
    }

    function moveDrag(clientX) {
      if (!dragging) {
        return;
      }

      /* Calcula o quanto o usuário arrastou. */
      currentX =
        clientX - startX;

      /* Não permitimos passar dos limites. */
      currentX =
        Math.max(
          0,
          Math.min(
            maxMove,
            currentX
          )
        );

      knob.style.transform =
        `translateX(${currentX}px)`;

      /* Se chegar perto do final, completamos. */
      if (currentX >= maxMove - 5) {

        dragging = false;

        knob.style.transform =
          `translateX(${maxMove}px)`;

        button.classList.add("completed");

        text.textContent =
          "✓ Confirmado";

        notify(
          "✅ Confirmação por deslize concluída."
        );
      }
    }

    function endDrag() {
      if (!dragging) {
        return;
      }

      dragging = false;

      /* Se não concluiu, volta ao começo. */
      knob.style.transform =
        "translateX(0)";
    }

    /* Eventos do mouse. */
    button.addEventListener(
      "mousedown",
      (event) => {
        startDrag(event.clientX);
      }
    );

    window.addEventListener(
      "mousemove",
      (event) => {
        moveDrag(event.clientX);
      }
    );

    window.addEventListener(
      "mouseup",
      endDrag
    );

    /* Eventos touch. */
    button.addEventListener(
      "touchstart",
      (event) => {
        startDrag(
          event.touches[0].clientX
        );
      },
      { passive: true }
    );

    window.addEventListener(
      "touchmove",
      (event) => {
        if (dragging) {
          moveDrag(
            event.touches[0].clientX
          );
        }
      },
      { passive: true }
    );

    window.addEventListener(
      "touchend",
      endDrag
    );
  });
