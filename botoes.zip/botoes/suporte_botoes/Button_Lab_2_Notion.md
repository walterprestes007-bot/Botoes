# 🎨 BUTTON LAB 2.0 — GUIA COMPLETO DE CSS + JAVASCRIPT

> **Objetivo:** entender como criar, estilizar e programar 50 tipos diferentes de botões usando HTML, CSS e JavaScript.
>
> **Nível:** iniciante → intermediário → avançado.
>
> **Como estudar:** não memorize propriedades isoladas. Entenda a sequência **estrutura → aparência → interação → estado**.

---

# 🧭 1. COMO USAR ESTE NOTION

## A ordem mental para criar qualquer botão

Todo botão pode ser pensado em quatro perguntas:

### 1. O que existe?
É a parte do **HTML**.

Exemplo:

```html
<button class="btn btn-primary">
  Entrar
</button>
```

### 2. Como ele parece?
É a parte do **CSS**.

```css
.btn-primary {
  background: purple;
  color: white;
  border-radius: 10px;
}
```

### 3. O que acontece quando passo o mouse?
Normalmente usamos estados CSS:

```css
.btn-primary:hover {
  transform: translateY(-2px);
}
```

### 4. O que acontece quando clico?
Quando o comportamento precisa de lógica, usamos **JavaScript**:

```javascript
button.addEventListener("click", () => {
  console.log("Botão clicado");
});
```

---

# 🧱 2. FUNDAMENTOS ANTES DOS 50 BOTÕES

## HTML

### `<button>`

É o elemento semântico principal para ações.

```html
<button>Clique</button>
```

Use `button` quando a ação acontece na própria página.

### `<a>`

É usado para navegação.

```html
<a href="/contato">Contato</a>
```

Pode parecer um botão com CSS, mas semanticamente continua sendo um link.

### `<span>`

Serve para separar partes do conteúdo.

```html
<button>
  <span>Salvar</span>
  <span>→</span>
</button>
```

Isso permite animar apenas uma parte.

### `data-*`

Permite guardar dados personalizados no HTML.

```html
<button data-copy="npm install">
  Copiar
</button>
```

JavaScript pode acessar:

```javascript
button.dataset.copy;
```

### `aria-*`

Ajuda tecnologias assistivas a entenderem o estado ou finalidade do elemento.

Exemplo:

```html
<button aria-pressed="false">
  Favoritar
</button>
```

---

# 🎨 3. FUNDAMENTOS DE CSS

## `background`

Muda o fundo.

```css
background: purple;
```

Também pode receber gradiente:

```css
background: linear-gradient(90deg, purple, blue);
```

## `color`

Muda a cor do texto.

```css
color: white;
```

## `border`

Cria borda.

```css
border: 2px solid white;
```

## `border-radius`

Arredonda cantos.

```css
border-radius: 12px;
```

`999px` é frequentemente usado para criar formato de cápsula:

```css
border-radius: 999px;
```

## `box-shadow`

Cria sombra.

```css
box-shadow: 0 10px 30px rgba(0,0,0,.2);
```

Os valores representam, em geral:

```text
X  Y  blur  spread/color
```

## `transition`

Suaviza mudanças.

```css
transition: .25s ease;
```

Sem `transition`, um hover pode parecer instantâneo.

## `transform`

Move, gira ou escala.

```css
transform: translateY(-2px);
transform: scale(1.05);
transform: rotate(10deg);
```

## `:hover`

Estado quando o cursor está sobre o elemento.

```css
button:hover {
  background: blue;
}
```

## `:active`

Estado enquanto o usuário está pressionando.

```css
button:active {
  transform: scale(.96);
}
```

## `:disabled`

Estado de botão desabilitado.

```css
button:disabled {
  opacity: .5;
}
```

## `::before` e `::after`

Pseudo-elementos. São extremamente úteis para efeitos visuais.

```css
button::before {
  content: "";
}
```

Eles permitem criar brilhos, ondas, bordas, preenchimentos e formas sem adicionar novos elementos HTML.

## `@keyframes`

Cria uma animação.

```css
@keyframes aparecer {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}
```

Depois:

```css
button {
  animation: aparecer 1s ease;
}
```

---

# ⚙️ 4. FUNDAMENTOS DE JAVASCRIPT

## Selecionando um elemento

```javascript
const button =
  document.querySelector(".btn");
```

## Selecionando vários

```javascript
const buttons =
  document.querySelectorAll(".btn");
```

## Clique

```javascript
button.addEventListener("click", () => {
  console.log("clicou");
});
```

## Classes

Adicionar:

```javascript
button.classList.add("ativo");
```

Remover:

```javascript
button.classList.remove("ativo");
```

Alternar:

```javascript
button.classList.toggle("ativo");
```

## Temporizador

```javascript
setTimeout(() => {
  console.log("passaram 2 segundos");
}, 2000);
```

## Repetição

```javascript
setInterval(() => {
  console.log("executando");
}, 1000);
```

## Atributos

```javascript
button.setAttribute(
  "aria-pressed",
  "true"
);
```

Ler:

```javascript
button.getAttribute(
  "aria-pressed"
);
```

## Dados do HTML

```javascript
button.dataset.copy;
```

## Coordenadas do botão

```javascript
const rect =
  button.getBoundingClientRect();
```

Isso é útil para efeitos que dependem da posição do mouse.

---

# 📚 5. BOTÕES BÁSICOS

---

# 01 — PRIMARY

## 🎯 Para que serve

É o botão principal da interface.

Exemplos:

- Entrar
- Comprar
- Cadastrar
- Salvar
- Começar

## HTML

```html
<button class="btn btn-primary">
  Primary
</button>
```

## CSS

```css
.btn-primary {
  color: white;

  background:
    linear-gradient(
      135deg,
      #7c3aed,
      #5b21b6
    );

  box-shadow:
    0 10px 24px
    rgba(124, 58, 237, .28);
}
```

## Como funciona

1. `color: white` deixa o texto claro.
2. `linear-gradient()` cria duas cores no fundo.
3. `box-shadow` cria profundidade.
4. A classe `.btn` fornece tamanho, alinhamento e transições.

## Como criar do zero

Comece pelo mínimo:

```css
button {
  padding: 12px 20px;
  color: white;
  background: purple;
  border: none;
  border-radius: 10px;
}
```

Depois acrescente:

```css
background: linear-gradient(...);
box-shadow: ...;
```

## O que explicar

> “Primeiro criamos a estrutura com HTML. Depois o CSS transforma o botão visualmente. O gradiente não muda a estrutura; ele muda apenas a apresentação.”

---

# 02 — SECONDARY

## 🎯 Para que serve

É uma ação secundária.

Exemplo:

```text
Salvar        Cancelar
```

Salvar pode ser primary e cancelar secondary.

## HTML

```html
<button class="btn btn-secondary">
  Secondary
</button>
```

## CSS

```css
.btn-secondary {
  color: white;
  background: #334155;
  box-shadow:
    0 8px 20px rgba(0,0,0,.2);
}
```

## Conceito principal

O diferencial não está em uma animação complexa, mas na **hierarquia visual**.

Primary chama atenção.
Secondary fica mais discreto.

---

# 03 — OUTLINE

## 🎯 Para que serve

Quando você quer um botão com destaque sem preencher todo o fundo.

## HTML

```html
<button class="btn btn-outline">
  Outline
</button>
```

## CSS

```css
.btn-outline {
  color: #a78bfa;
  background: transparent;
  border: 1.5px solid #8b5cf6;
}
```

## Propriedades importantes

### `background: transparent`

Remove o preenchimento.

### `border`

Faz a forma ser percebida através da borda.

### Como melhorar

```css
.btn-outline:hover {
  color: white;
  background: #8b5cf6;
}
```

Assim você transforma o botão em um botão de preenchimento progressivo simples.

---

# 04 — GHOST

## 🎯 Para que serve

Botão extremamente discreto.

Ótimo para:

- menus
- ferramentas
- cabeçalhos
- ações secundárias

## HTML

```html
<button class="btn btn-ghost">
  Ghost
</button>
```

## CSS

```css
.btn-ghost {
  color: var(--text);
  background: transparent;
}

.btn-ghost:hover {
  background:
    rgba(139,92,246,.12);
}
```

## Conceito

O hover cria contexto para o usuário descobrir que aquilo é interativo.

---

# 05 — DANGER

## 🎯 Para que serve

Para ações destrutivas.

```html
<button class="btn btn-danger">
  Excluir
</button>
```

```css
.btn-danger {
  color: white;

  background:
    linear-gradient(
      135deg,
      #ef4444,
      #b91c1c
    );
}
```

## Regra de UX

Use vermelho quando realmente existir uma ação crítica.

Evite deixar uma tela inteira cheia de botões vermelhos.

---

# 06 — SUCCESS

## 🎯 Para que serve

Confirmação.

```html
<button class="btn btn-success">
  Confirmar
</button>
```

```css
.btn-success {
  color: white;

  background:
    linear-gradient(
      135deg,
      #22c55e,
      #15803d
    );
}
```

---

# 07 — WARNING

## 🎯 Para que serve

Alertar sem representar necessariamente uma ação destrutiva.

```html
<button class="btn btn-warning">
  Atenção
</button>
```

```css
.btn-warning {
  color: #1c1917;

  background:
    linear-gradient(
      135deg,
      #facc15,
      #f59e0b
    );
}
```

Observe que o texto é escuro para manter contraste visual.

---

# 🌌 6. EFEITOS VISUAIS

---

# 08 — NEON GLOW

## 🎯 Ideia

Criar a sensação de luz.

## HTML

```html
<button class="btn btn-neon">
  NEON
</button>
```

## CSS

```css
.btn-neon {
  color: #67e8f9;

  background: #071017;

  border: 1px solid #22d3ee;

  box-shadow:
    0 0 10px rgba(34,211,238,.55),
    inset 0 0 14px
    rgba(34,211,238,.10);

  text-shadow:
    0 0 8px rgba(103,232,249,.8);
}
```

## Como o efeito é criado

A aparência de neon depende de três coisas:

1. borda luminosa;
2. sombra externa;
3. sombra interna/text-shadow.

## Fórmula mental

```text
borda + glow externo + glow no texto = neon
```

## Desafio

Faça um neon rosa:

```css
#ec4899
```

---

# 09 — GRADIENT

## Ideia

Usar várias cores no mesmo fundo.

```css
.btn-gradient {
  background:
    linear-gradient(
      100deg,
      #ec4899,
      #8b5cf6,
      #06b6d4
    );
}
```

## Animação

O truque é aumentar o tamanho do background:

```css
background-size: 200% auto;
```

E depois movê-lo:

```css
@keyframes gradientMove {
  to {
    background-position: 200% center;
  }
}
```

---

# 10 — 3D

## Ideia

Imitar um botão físico.

```css
.btn-3d {
  background: #2563eb;
  border-bottom: 6px solid #1d4ed8;
}
```

Ao pressionar:

```css
.btn-3d:active {
  transform: translateY(4px);
  border-bottom-width: 2px;
}
```

## Por que parece 3D?

Porque temos:

```text
superfície
+
borda inferior
+
movimento para baixo
```

---

# 11 — PILL

## Ideia

Formato de cápsula.

```css
border-radius: 999px;
```

Quanto maior o `border-radius`, mais arredondado fica.

---

# 12 — BOTÕES DE ÍCONE

## HTML

```html
<button class="icon-btn">
  ♡
</button>
```

## CSS

```css
.icon-btn {
  width: 46px;
  height: 46px;

  display: grid;
  place-items: center;

  border-radius: 50%;
}
```

## Conceito

Quando largura e altura são iguais e o `border-radius` é `50%`, o botão fica circular.

---

# ⏳ 7. ESTADOS E MICROINTERAÇÕES

---

# 13 — LOADING

## Objetivo

Informar que o sistema está trabalhando.

## HTML

```html
<button class="btn btn-primary js-loading">
  Enviar
</button>
```

## JavaScript

```javascript
button.addEventListener("click", () => {
  button.classList.add("loading");

  setTimeout(() => {
    button.classList.remove("loading");
  }, 1800);
});
```

## O raciocínio

```text
clicou
↓
adiciona classe loading
↓
CSS mostra spinner
↓
aguarda
↓
remove classe
```

## Por que usar classe?

Porque o JavaScript cuida do **estado** e o CSS cuida da **aparência**.

Esse padrão é extremamente útil.

---

# 14 — TOGGLE

## Ideia

Um botão pode representar dois estados.

```text
OFF → ON
```

## HTML

```html
<button
  class="toggle"
  aria-pressed="false"
>
  <span></span>
  <strong>OFF</strong>
</button>
```

## JavaScript

```javascript
const active =
  toggle.getAttribute("aria-pressed")
  === "true";

toggle.setAttribute(
  "aria-pressed",
  String(!active)
);
```

## Conceito importante

O atributo representa o estado.

```text
false = desligado
true  = ligado
```

---

# 15 — RIPPLE

## Ideia

A onda nasce exatamente no ponto do clique.

## JavaScript essencial

```javascript
const rect =
  button.getBoundingClientRect();

const x =
  event.clientX - rect.left;

const y =
  event.clientY - rect.top;

button.style.setProperty(
  "--x",
  `${x}px`
);

button.style.setProperty(
  "--y",
  `${y}px`
);
```

## CSS

```css
.btn-ripple::after {
  content: "";
  position: absolute;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: white;
  transform: scale(0);
}
```

Depois o estado `.ripple` aumenta o círculo.

## O conceito mais importante

JavaScript calcula a posição.

CSS faz a animação.

---

# 16 — SHINE

## Ideia

Uma faixa de luz passa pelo botão.

## A técnica

Criamos uma faixa com `::before`.

```css
.btn-shine::before {
  content: "";

  position: absolute;

  width: 55px;

  background:
    rgba(255,255,255,.45);

  transform:
    skewX(-20deg);
}
```

Depois movemos:

```css
.btn-shine:hover::before {
  left: 120%;
}
```

## Conceito

Pseudo-elementos são ótimos para efeitos que não precisam existir no HTML.

---

# 17 — MAGNETIC

## Ideia

O botão segue o cursor.

## JavaScript

```javascript
const rect =
  button.getBoundingClientRect();

const centerX =
  rect.left + rect.width / 2;

const centerY =
  rect.top + rect.height / 2;

const distanceX =
  event.clientX - centerX;

const distanceY =
  event.clientY - centerY;
```

Depois:

```javascript
button.style.transform =
  `translate(
    ${distanceX * 0.18}px,
    ${distanceY * 0.18}px
  )`;
```

## Conceito

Você está transformando a distância do mouse em movimento.

---

# 18 — ANIMATED BORDER

## Ferramentas

- `conic-gradient`
- `@property`
- `@keyframes`
- border transparente

## Ideia

```css
background:
  linear-gradient(#111827,#111827) padding-box,
  conic-gradient(
    from var(--angle),
    purple,
    cyan,
    pink,
    purple
  ) border-box;
```

O valor:

```css
--angle: 0deg;
```

vira:

```css
--angle: 360deg;
```

durante a animação.

---

# 19 — GLASSMORPHISM

## Elementos

```css
background:
  rgba(255,255,255,.1);

backdrop-filter:
  blur(12px);
```

## O que faz `backdrop-filter`?

Aplica um efeito sobre o conteúdo que está atrás do elemento.

Resultado:

```text
fundo
↓
desfoque
↓
camada transparente
↓
efeito de vidro
```

---

# 20 — GRADIENT BORDER

## Técnica

Duas camadas de background:

```css
background:
  linear-gradient(#111827,#111827) padding-box,
  linear-gradient(
    90deg,
    cyan,
    purple,
    pink
  ) border-box;
```

A primeira camada preenche o interior.

A segunda fica atrás da borda transparente.

---

# 21 — CUT CORNER

## Ferramenta

`clip-path`.

```css
clip-path:
  polygon(
    8% 0,
    100% 0,
    92% 100%,
    0 100%
  );
```

## Ideia

Em vez de desenhar uma forma especial com várias `div`s, recortamos visualmente o próprio botão.

---

# 22 — HOLOGRAPHIC

## Ideia

Gradiente com várias cores + movimento.

```css
background:
  linear-gradient(
    110deg,
    pink,
    blue,
    purple,
    mint,
    pink
  );

background-size:
  300% 300%;
```

Depois animamos `background-position`.

---

# 23 — SOCIAL

## Ideia

Criar hierarquia visual baseada em identidade.

```html
<button class="social-btn github">
  GitHub
</button>
```

```css
.github {
  background: #24292f;
}
```

Outro botão:

```css
.discord {
  background: #5865f2;
}
```

A mesma estrutura pode receber temas diferentes apenas trocando classes.

---

# 24 — LOGIN CTA

## Ideia

Uma ação de entrada com seta.

```html
<button class="btn btn-login">
  Entrar
  <span>→</span>
</button>
```

## CSS

A seta recebe:

```css
transition:
  transform .2s ease;
```

E no hover:

```css
.btn-login:hover span {
  transform:
    translateX(5px);
}
```

## Conceito

Você não precisa animar o botão inteiro. Pode animar somente um elemento interno.

---

# 25 — DOWNLOAD

## Objetivo

Representar progresso.

## JavaScript

```javascript
let progress = 0;

const timer =
  setInterval(() => {
    progress += 20;

    button.textContent =
      `Baixando ${progress}%`;
  }, 220);
```

## Conceito

`setInterval` executa repetidamente até ser parado.

Parar:

```javascript
clearInterval(timer);
```

---

# 26 — COPY

## API utilizada

```javascript
navigator.clipboard.writeText(
  value
);
```

## Fluxo

```text
botão
↓
data-copy
↓
JavaScript lê dataset.copy
↓
Clipboard API
↓
texto copiado
```

## Exemplo

```html
<button
  class="btn-copy"
  data-copy="npm install"
>
  Copiar
</button>
```

---

# 27 — DISABLED

## HTML

```html
<button disabled>
  Indisponível
</button>
```

## CSS

```css
button:disabled {
  opacity: .45;
  cursor: not-allowed;
}
```

## Conceito

Disabled não é simplesmente “um botão cinza”.

Ele representa um estado funcional: **a ação não está disponível naquele momento**.

---

# 28 — LINK BUTTON

## HTML

```html
<a href="/contato" class="btn btn-link">
  Contato
</a>
```

## Quando usar

Se o objetivo é navegar para outro lugar, prefira `a`.

Se o objetivo é executar uma ação na interface, prefira `button`.

Isso melhora semântica e acessibilidade.

---

# 29 — HAMBURGER

## Estrutura

```html
<button class="hamburger">
  <i></i>
  <i></i>
  <i></i>
</button>
```

São três linhas.

No estado aberto:

```css
.hamburger.open i:nth-child(1) {
  transform:
    translateY(8px)
    rotate(45deg);
}
```

A segunda desaparece.

A terceira gira na direção oposta.

## Resultado

Três linhas:

```text
☰
```

viram:

```text
×
```

---

# 30 — SQUISHY

## Ideia

Comprimir e expandir.

```css
@keyframes squish {
  0% {
    transform: scale(1);
  }

  40% {
    transform: scale(.86,1.12);
  }

  70% {
    transform: scale(1.08,.94);
  }

  100% {
    transform: scale(1);
  }
}
```

## Conceito

O efeito vem da combinação entre:

```text
scale horizontal
+
scale vertical
+
tempo
```

---

# 🚀 8. BOTÕES AVANÇADOS

---

# 31 — FLIP 3D

## Ideia

O botão vira no eixo X.

## HTML

```html
<button class="btn btn-flip">
  <span class="front">
    HOVER
  </span>

  <span class="back">
    OLÁ!
  </span>
</button>
```

## CSS

```css
transform-style:
  preserve-3d;
```

No hover:

```css
transform:
  rotateX(180deg);
```

## Para esconder a parte de trás corretamente

```css
backface-visibility:
  hidden;
```

## Conceito

São duas faces no mesmo objeto tridimensional.

---

# 32 — LIQUID

## Ideia

Usar um pseudo-elemento enorme por trás do texto.

```css
.btn-liquid::before {
  content: "";

  position: absolute;

  left: -20%;
  bottom: -65%;

  width: 140%;
  height: 130%;
}
```

Quando fazemos:

```css
.btn-liquid:hover::before {
  bottom: -5%;
}
```

o preenchimento parece subir.

---

# 33 — PULSE

## Ideia

Criar ondas saindo do botão.

```css
@keyframes pulse {
  0% {
    box-shadow:
      0 0 0 0
      rgba(124,58,237,.55);
  }

  70% {
    box-shadow:
      0 0 0 18px
      rgba(124,58,237,0);
  }
}
```

## Conceito

A sombra começa perto do botão e aumenta até desaparecer.

Isso cria a sensação de pulsação.

---

# 34 — TYPING

## Ideia

Simular máquina de escrever.

## CSS principal

```css
.btn-typing span {
  overflow: hidden;
  white-space: nowrap;

  animation:
    typing 2.5s steps(10)
    infinite alternate;
}
```

O segredo é:

```css
steps()
```

Em vez de uma animação contínua, o texto avança em “passos”.

---

# 35 — ALERT

## Objetivo

Mostrar uma confirmação ou aviso.

## Exemplo de JavaScript

```javascript
button.addEventListener(
  "click",
  () => {
    window.alert(
      "Você clicou!"
    );
  }
);
```

## Melhor versão

Em aplicações reais, você pode criar seu próprio modal em HTML/CSS em vez de depender do `alert()` nativo.

---

# 36 — DOUBLE CLICK

## Evento

```javascript
button.addEventListener(
  "dblclick",
  () => {
    console.log(
      "duplo clique"
    );
  }
);
```

## Quando usar

É útil para:

- favoritos rápidos
- ações escondidas
- interações parecidas com galerias

Mas não deve ser usado para ações críticas porque nem todo usuário percebe que precisa clicar duas vezes.

---

# 37 — LONG PRESS

## Ideia

Executar depois de manter pressionado.

O conceito é:

```text
mousedown
↓
inicia timer
↓
usuário continua segurando?
↓
ação
```

Se soltar antes:

```text
mouseup
↓
cancela timer
```

## Exemplo

```javascript
let timer;

button.addEventListener(
  "mousedown",
  () => {
    timer = setTimeout(
      () => {
        console.log(
          "segurou"
        );
      },
      1000
    );
  }
);

button.addEventListener(
  "mouseup",
  () => {
    clearTimeout(timer);
  }
);
```

---

# 38 — CONFIRM

## Ideia

Transformar:

```text
Excluir item
```

em:

```text
✓ Excluído
```

## Conceito

Uma classe representa o novo estado:

```javascript
button.classList.add(
  "confirmed"
);
```

E o CSS muda a aparência.

---

# 39 — SPLIT BUTTON

## Estrutura

Um botão é dividido em duas áreas:

```text
┌──────────────┬───┐
│    Salvar    │⌄  │
└──────────────┴───┘
```

A primeira executa a ação principal.

A segunda abre outras opções.

## HTML

```html
<div class="split">

  <button class="split-main">
    Salvar
  </button>

  <button class="split-arrow">
    ⌄
  </button>

  <div class="split-menu">
    <button>
      Salvar como...
    </button>

    <button>
      Salvar e fechar
    </button>
  </div>

</div>
```

## JavaScript

O importante é alternar:

```javascript
split.classList.toggle(
  "open"
);
```

O CSS decide:

```css
.split.open .split-menu {
  display: grid;
}
```

---

# 40 — PROGRESS CIRCULAR

## Técnica

Usar `conic-gradient`.

```css
background:
  conic-gradient(
    purple 180deg,
    gray 180deg
  );
```

360 graus = 100%.

Portanto:

```text
0%   = 0 graus
25%  = 90 graus
50%  = 180 graus
75%  = 270 graus
100% = 360 graus
```

A fórmula é:

```javascript
const degrees =
  progress * 3.6;
```

---

# 41 — CURSOR

## Exemplo

```css
button {
  cursor: crosshair;
}
```

Outros exemplos:

```css
cursor: pointer;
cursor: grab;
cursor: not-allowed;
cursor: help;
cursor: wait;
```

## Conceito

Cursor muda a indicação visual, mas nunca deve ser a única maneira de comunicar o estado.

---

# 42 — DOUBLE BORDER

## Técnica

Usar duas camadas de borda através de `box-shadow` interno.

```css
box-shadow:
  inset 0 0 0 3px #111827,
  inset 0 0 0 5px #8b5cf6;
```

É uma ótima técnica para criar molduras sem adicionar HTML extra.

---

# 43 — HOVER TEXT

## Ideia

Mudar o conteúdo durante hover.

### CSS

```css
.btn-hover-text:hover span {
  font-size: 0;
}

.btn-hover-text:hover span::after {
  content: "Agora clique!";
  font-size: .92rem;
}
```

Também pode ser feito com JavaScript.

### JavaScript

```javascript
button.addEventListener(
  "mouseenter",
  () => {
    span.textContent =
      "Agora clique!";
  }
);
```

---

# 44 — SCAN

## Ideia

Criar aparência de interface futurista.

Uma linha de luz é criada com `::after`.

```css
.btn-scan::after {
  content: "";

  position: absolute;

  width: 26px;

  background:
    linear-gradient(
      90deg,
      transparent,
      rgba(94,234,212,.55),
      transparent
    );

  animation:
    scan 2.2s linear infinite;
}
```

---

# 45 — ORBIT

## Ideia

Criar uma borda que parece estar orbitando.

## Técnica

```css
.btn-orbit::before {
  content: "";

  position: absolute;

  inset: -7px;

  border-radius: 999px;

  border:
    1px solid
    rgba(34,211,238,.55);

  animation:
    orbitSpin 1.5s
    linear infinite;
}
```

Depois:

```css
@keyframes orbitSpin {
  to {
    transform:
      rotate(360deg);
  }
}
```

---

# 46 — FALLING

## Ideia

Animar letras individualmente.

## HTML

```html
<button>
  <span>F</span>
  <span>A</span>
  <span>L</span>
  <span>L</span>
  <span>I</span>
  <span>N</span>
  <span>G</span>
</button>
```

Cada `span` recebe uma pequena diferença de tempo:

```css
span:nth-child(2) {
  animation-delay: .05s;
}
```

Isso cria uma sequência.

---

# 47 — GOOEY

## Ideia

Criar pequenos círculos que se movem ao redor do botão.

O HTML possui elementos adicionais:

```html
<button class="gooey-btn">
  <span>GOOEY</span>
  <i></i>
  <i></i>
  <i></i>
</button>
```

Cada `<i>` recebe:

```css
border-radius: 50%;
```

e vira uma pequena esfera.

No hover:

```css
transform:
  translate(...)
  scale(...);
```

O segredo é criar movimentos diferentes para cada bolinha.

---

# 48 — SLIDE TO CONFIRM

## Ideia

O usuário precisa arrastar.

```text
[ →    Deslize      ]
```

Até:

```text
[       ✓ Confirmado]
```

## Conceito

Você precisa acompanhar a coordenada X do toque/mouse.

```javascript
currentX =
  clientX - startX;
```

Depois limita:

```javascript
Math.min(
  maxMove,
  currentX
);
```

Isso impede que o botão ultrapasse o espaço definido.

---

# 49 — NOTIFICATION

## Estrutura

```html
<button class="notification-btn">
  🔔
  <span>3</span>
</button>
```

O `span` é o contador.

## CSS

Posicionamento:

```css
.notification-btn > span {
  position: absolute;

  top: -4px;
  right: -4px;
}
```

O segredo é o botão pai ser:

```css
position: relative;
```

Assim o contador consegue ser posicionado em relação ao próprio botão.

---

# 50 — FAVORITE

## Ideia

Microinteração para favoritar.

## HTML

```html
<button class="favorite-btn">
  <span>♡</span>
</button>
```

## JavaScript

```javascript
const active =
  button.classList.toggle(
    "active"
  );

button.querySelector("span")
  .textContent =
  active ? "♥" : "♡";
```

## CSS

Quando ativo:

```css
.favorite-btn.active span {
  transform:
    scale(1.28);
}
```

Assim temos três camadas:

```text
estado
↓
classe active
↓
CSS altera visual
```

---

# 🧪 9. PADRÃO PROFISSIONAL PARA CRIAR QUALQUER BOTÃO

Use este roteiro.

## Etapa 1 — HTML

Pergunte:

> Qual informação e quais partes o botão precisa?

Exemplo:

```html
<button class="meu-botao">
  <span>Salvar</span>
  <span>→</span>
</button>
```

---

## Etapa 2 — Base CSS

Crie primeiro:

```css
.meu-botao {
  padding: 12px 20px;
  border: none;
  border-radius: 12px;
  cursor: pointer;
}
```

Não tente fazer o efeito complexo imediatamente.

---

## Etapa 3 — Hover

```css
.meu-botao:hover {
  transform: translateY(-2px);
}
```

---

## Etapa 4 — Active

```css
.meu-botao:active {
  transform: scale(.97);
}
```

---

## Etapa 5 — Animação

Só depois adicione:

```css
@keyframes ...
```

---

## Etapa 6 — JavaScript

Somente quando existir comportamento dinâmico:

```javascript
button.addEventListener(
  "click",
  () => {
    ...
  }
);
```

---

# 🧠 10. PADRÕES DE CÓDIGO QUE APARECEM VÁRIAS VEZES

## Padrão A — CSS controla o estado

Exemplo:

```css
button:hover {
  transform: scale(1.05);
}
```

Não precisa de JavaScript.

Use CSS quando a interação for puramente visual.

---

## Padrão B — JavaScript troca classe

```javascript
button.classList.add("active");
```

E:

```css
button.active {
  ...
}
```

Esse é um dos padrões mais importantes para aprender.

---

## Padrão C — JavaScript altera conteúdo

```javascript
button.textContent =
  "Concluído!";
```

Use quando o texto realmente precisa mudar.

---

## Padrão D — JavaScript inicia e encerra tempo

```javascript
const timer =
  setTimeout(() => {
    ...
  }, 1000);

clearTimeout(timer);
```

Muito útil para:

- long press
- loading
- mensagens temporárias
- delays

---

## Padrão E — `setInterval`

```javascript
const interval =
  setInterval(() => {
    progress += 10;
  }, 100);
```

Use para processos progressivos.

Finalize com:

```javascript
clearInterval(interval);
```

---

## Padrão F — variável CSS controlada pelo JS

```javascript
button.style.setProperty(
  "--progress",
  "70%"
);
```

Depois CSS:

```css
button {
  width: var(--progress);
}
```

Isso cria uma ponte poderosa entre JavaScript e CSS.

---

# 🏗️ 11. COMO CRIAR UM BOTÃO DO ZERO

## Exemplo: botão de partículas

### Passo 1 — HTML

```html
<button class="particle-button">
  Clique
</button>
```

### Passo 2 — aparência

```css
.particle-button {
  position: relative;
  padding: 14px 24px;
  color: white;
  background: #7c3aed;
  border-radius: 12px;
}
```

### Passo 3 — clique

```javascript
button.addEventListener(
  "click",
  () => {
    criarParticulas();
  }
);
```

### Passo 4 — criar elementos

```javascript
function criarParticulas() {

  for (let i = 0; i < 12; i++) {

    const particle =
      document.createElement("span");

    particle.classList.add(
      "particle"
    );

    document.body.appendChild(
      particle
    );
  }
}
```

### Passo 5 — animar com CSS

```css
@keyframes particleMove {
  from {
    transform: translate(0,0);
    opacity: 1;
  }

  to {
    transform:
      translate(
        100px,
        -80px
      );
    opacity: 0;
  }
}
```

O mesmo raciocínio permite criar muitos outros efeitos.

---

# 🎓 12. ROTEIRO PARA EXPLICAR UM BOTÃO EM UMA APRESENTAÇÃO

Use esta ordem:

## 1. Objetivo

> “Este botão serve para…”

## 2. HTML

> “A estrutura é criada com…”

## 3. Classe

> “A classe identifica este componente…”

## 4. CSS base

> “Aqui definimos tamanho, cor e formato…”

## 5. Estado

> “No hover…”

## 6. Animação

> “O `@keyframes` faz…”

## 7. JavaScript

> “Quando o usuário clica…”

## 8. Estado final

> “Depois da ação, adicionamos/removemos a classe…”

---

# 📝 13. CHECKLIST PARA ANALISAR UM BOTÃO

Antes de dizer que entendeu, responda:

### HTML
- Qual é o elemento principal?
- Existem `span`s?
- Existem atributos `data-*`?
- Existem atributos `aria-*`?
- É `button` ou `a`?

### CSS
- Como o tamanho é definido?
- Como os cantos são arredondados?
- Existe `box-shadow`?
- Existe gradiente?
- Existe `hover`?
- Existe `active`?
- Existe `::before`?
- Existe `::after`?
- Existe `@keyframes`?
- Existe `transform`?
- Existe `transition`?

### JavaScript
- Qual elemento é selecionado?
- Qual evento é utilizado?
- O código adiciona classe?
- Remove classe?
- Altera texto?
- Usa timer?
- Usa posição do mouse?
- Usa atributo?
- Usa API do navegador?

---

# 🔥 14. DESAFIOS POR NÍVEL

## 🟢 Nível 1 — iniciante

Crie:

1. Primary
2. Secondary
3. Outline
4. Pill
5. Danger

Sem olhar o projeto.

---

## 🟡 Nível 2 — intermediário

Crie:

1. Loading
2. Toggle
3. Copy
4. Favorite
5. Notification

Use JavaScript.

---

## 🟠 Nível 3 — avançado

Crie:

1. Ripple
2. Magnetic
3. Split Button
4. Progress Circular
5. Slide to Confirm

---

## 🔴 Nível 4 — desafio

Crie sem copiar nenhum código:

- Particle
- Fire
- Electric
- Water
- Hologram
- Glitch
- Sound
- 3D rotating
- Radar
- Cyberpunk

---

# 🧩 15. REGRA DE OURO

Quando você estiver criando um efeito, não tente decorar:

```text
“qual código faz esse botão?”
```

Pense:

```text
O que preciso mudar?
↓
posição?
cor?
tamanho?
opacidade?
borda?
texto?
estado?
tempo?
movimento?
```

Depois escolha a ferramenta:

```text
aparência → CSS
animação → CSS
estado → classe/atributo
lógica → JavaScript
tempo → setTimeout/setInterval
mouse → eventos de mouse
toque → eventos touch
dados → data-* / dataset
```

---

# ✅ 16. RESUMO FINAL

Os 50 botões não são 50 assuntos totalmente diferentes.

Eles são combinações das mesmas ideias:

```text
HTML
+
CSS
+
Estados
+
Transform
+
Transition
+
Keyframes
+
Pseudo-elementos
+
JavaScript
=
Microinterações
```

Quando você domina:

- `classList`
- `addEventListener`
- `:hover`
- `:active`
- `transform`
- `transition`
- `box-shadow`
- `::before`
- `::after`
- `@keyframes`
- `setTimeout`
- `setInterval`
- `getBoundingClientRect`
- `dataset`

você já consegue construir uma quantidade enorme de componentes interativos.

---

# 🚀 PROJETO FINAL

Crie uma pasta chamada:

```text
button-lab-final
```

E faça:

```text
index.html
style.css
script.js
```

Objetivo:

### HTML

Tenha pelo menos 10 botões completamente seus.

### CSS

Cada botão deve possuir pelo menos uma microinteração.

### JavaScript

Pelo menos 5 botões devem ter comportamento diferente.

### Regra

Não copie os 50 exemplos.

Use os conceitos.

Esse é o ponto em que você deixa de apenas reproduzir botões e começa a saber **criar componentes**.
