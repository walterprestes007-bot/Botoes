# Button Lab 2.0

Projeto de estudo para aprender **HTML, CSS e JavaScript** através de 50 exemplos de botões.

## Como abrir

1. Extraia o `.zip`.
2. Abra a pasta no VS Code.
3. Abra `index.html`.
4. Recomendo usar a extensão **Live Server**.
5. Clique em **Go Live**.

## Arquivos

- `index.html` → estrutura da página e dos exemplos.
- `style.css` → visual, animações, transições, pseudo-elementos e responsividade.
- `script.js` → interações e comportamentos.
- `README.md` → guia rápido.

## Os 50 exemplos

1. Primary
2. Secondary
3. Outline
4. Ghost
5. Danger
6. Success
7. Warning
8. Neon Glow
9. Gradient
10. 3D
11. Pill
12. Ícones
13. Loading
14. Toggle
15. Ripple
16. Shine
17. Magnetic
18. Animated Border
19. Glassmorphism
20. Gradient Border
21. Cut Corner
22. Holographic
23. Social
24. Login CTA
25. Download
26. Copy
27. Disabled
28. Link
29. Hamburger
30. Squishy
31. Flip 3D
32. Liquid
33. Pulse
34. Typing
35. Alert
36. Double Click
37. Long Press
38. Confirm
39. Split Button
40. Progress Circular
41. Cursor
42. Double Border
43. Hover Text
44. Scan
45. Orbit
46. Falling
47. Gooey
48. Slide to Confirm
49. Notification
50. Favorite

## Como apresentar

Uma maneira boa de explicar um botão é dividir em três camadas:

### HTML
Explica a estrutura:
- `button`
- `span`
- `data-*`
- `aria-*`

### CSS
Explica aparência e animação:
- `background`
- `border`
- `box-shadow`
- `transform`
- `transition`
- `::before`
- `::after`
- `@keyframes`
- `@property`
- `clip-path`
- `backdrop-filter`

### JavaScript
Explica comportamento:
- `querySelector`
- `addEventListener`
- `classList`
- `setTimeout`
- `setInterval`
- `getBoundingClientRect`
- `dataset`
- `navigator.clipboard`
- eventos de mouse e touch

## Forma de estudar

Não fique só copiando.

Escolha um botão e faça:

1. Leia os comentários.
2. Entenda a parte HTML.
3. Entenda o CSS.
4. Veja o JavaScript.
5. Feche o projeto.
6. Tente recriar o efeito do zero.
7. Compare seu resultado com o original.

## Desafio final

Crie 5 botões novos sem copiar nenhum dos 50:

- partículas
- fogo
- chuva
- botão de som
- botão com microinteração própria
